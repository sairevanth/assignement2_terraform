#!/bin/bash
cd /home/N01600239/automation/ansible
ansible-playbook n01600239-playbook.yaml